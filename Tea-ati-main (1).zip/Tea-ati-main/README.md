# Tea-ati
Tea incentivized tesnet is a live
